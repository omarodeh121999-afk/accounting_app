import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(AccountingApp(store: store));
}

class AppStore extends ChangeNotifier {
  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> customers = [];
  List<Map<String, dynamic>> suppliers = [];
  List<Map<String, dynamic>> employees = [];
  List<Map<String, dynamic>> sales = [];
  List<Map<String, dynamic>> purchases = [];
  List<Map<String, dynamic>> expenses = [];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    products = _read(p, 'products');
    customers = _read(p, 'customers');
    suppliers = _read(p, 'suppliers');
    employees = _read(p, 'employees');
    sales = _read(p, 'sales');
    purchases = _read(p, 'purchases');
    expenses = _read(p, 'expenses');
  }

  List<Map<String, dynamic>> _read(SharedPreferences p, String key) {
    final raw = p.getString(key);
    if (raw == null) return [];
    return List<Map<String, dynamic>>.from(
      (jsonDecode(raw) as List).map((e) => Map<String, dynamic>.from(e)),
    );
  }

  Future<void> _save(String key, List<Map<String, dynamic>> value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(value));
  }

  Future<void> addProduct(String name, double buy, double sell, double qty) async {
    products.add({'name': name, 'buy': buy, 'sell': sell, 'qty': qty});
    await _save('products', products);
    notifyListeners();
  }

  Future<void> addCustomer(String name, String phone) async {
    customers.add({'name': name, 'phone': phone, 'balance': 0.0});
    await _save('customers', customers);
    notifyListeners();
  }

  Future<void> addSupplier(String name, String phone) async {
    suppliers.add({'name': name, 'phone': phone, 'balance': 0.0});
    await _save('suppliers', suppliers);
    notifyListeners();
  }

  Future<void> addEmployee(String name, String job, double salary) async {
    employees.add({'name': name, 'job': job, 'salary': salary});
    await _save('employees', employees);
    notifyListeners();
  }

  Future<void> addExpense(String type, double amount) async {
    expenses.add({'type': type, 'amount': amount, 'date': DateTime.now().toIso8601String()});
    await _save('expenses', expenses);
    notifyListeners();
  }

  Future<void> addSale(double amount) async {
    sales.add({'amount': amount, 'date': DateTime.now().toIso8601String()});
    await _save('sales', sales);
    notifyListeners();
  }

  Future<void> addPurchase(double amount) async {
    purchases.add({'amount': amount, 'date': DateTime.now().toIso8601String()});
    await _save('purchases', purchases);
    notifyListeners();
  }

  double get totalSales => sales.fold(0, (s, e) => s + (e['amount'] as num).toDouble());
  double get totalPurchases => purchases.fold(0, (s, e) => s + (e['amount'] as num).toDouble());
  double get totalExpenses => expenses.fold(0, (s, e) => s + (e['amount'] as num).toDouble());
  double get profit => totalSales - totalPurchases - totalExpenses;
}

class AccountingApp extends StatelessWidget {
  final AppStore store;
  const AccountingApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'نظام المحاسبة',
        theme: ThemeData(
          useMaterial3: true,
          fontFamily: 'sans',
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF17324D)),
          scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        ),
        home: Directionality(
          textDirection: TextDirection.rtl,
          child: HomePage(store: store),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final AppStore store;
  const HomePage({super.key, required this.store});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(store: widget.store),
      SimpleListPage(title: 'فواتير المبيعات', icon: Icons.receipt_long, items: widget.store.sales, empty: 'لا توجد فواتير مبيعات', onAdd: () => _amountDialog('فاتورة مبيعات', widget.store.addSale)),
      SimpleListPage(title: 'فواتير المشتريات', icon: Icons.shopping_cart, items: widget.store.purchases, empty: 'لا توجد فواتير مشتريات', onAdd: () => _amountDialog('فاتورة مشتريات', widget.store.addPurchase)),
      ProductsPage(store: widget.store),
      PeoplePage(title: 'العملاء', icon: Icons.people, items: widget.store.customers, fields: ['name','phone'], onAdd: () => _personDialog('إضافة عميل', widget.store.addCustomer)),
      PeoplePage(title: 'الموردون', icon: Icons.local_shipping, items: widget.store.suppliers, fields: ['name','phone'], onAdd: () => _personDialog('إضافة مورد', widget.store.addSupplier)),
      ExpensesPage(store: widget.store),
      EmployeesPage(store: widget.store),
      ReportsPage(store: widget.store),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(['الرئيسية','فواتير المبيعات','فواتير المشتريات','المخزون','العملاء','الموردون','المصروفات','العاملون','التقارير'][index]),
        backgroundColor: const Color(0xFF17324D),
        foregroundColor: Colors.white,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),
              color: const Color(0xFF17324D),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('نظام المحاسبة', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 6),
                Text('إدارة الحسابات والمخزون', style: TextStyle(color: Colors.white70)),
              ]),
            ),
            for (int i = 0; i < 9; i++)
              ListTile(
                leading: Icon([Icons.dashboard,Icons.receipt_long,Icons.shopping_cart,Icons.inventory_2,Icons.people,Icons.local_shipping,Icons.payments,Icons.badge,Icons.bar_chart][i]),
                title: Text(['الرئيسية','فاتورة مبيعات','فاتورة مشتريات','المخزون','العملاء','الموردون','المصروفات','العاملون','التقارير'][i]),
                selected: index == i,
                onTap: () { setState(() => index = i); Navigator.pop(context); },
              ),
          ],
        ),
      ),
      body: pages[index],
    );
  }

  Future<void> _amountDialog(String title, Future<void> Function(double) save) async {
    final c = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ بالشيكل ₪')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: () { final v = double.tryParse(c.text) ?? 0; save(v); Navigator.pop(context); }, child: const Text('حفظ')),
      ],
    ));
  }

  Future<void> _personDialog(String title, Future<void> Function(String,String) save) async {
    final n = TextEditingController(), p = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: Text(title),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: n, decoration: const InputDecoration(labelText: 'الاسم')),
        TextField(controller: p, decoration: const InputDecoration(labelText: 'رقم الهاتف')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: () { save(n.text, p.text); Navigator.pop(context); }, child: const Text('حفظ')),
      ],
    ));
  }
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  const Dashboard({super.key, required this.store});

  Widget card(String title, double value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
      CircleAvatar(child: Icon(icon)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Colors.grey)),
        const SizedBox(height: 4),
        Text('₪ ${value.toStringAsFixed(2)}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      ])),
    ])),
  );

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('ملخص اليوم', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      card('إجمالي المبيعات', store.totalSales, Icons.trending_up),
      card('إجمالي المشتريات', store.totalPurchases, Icons.shopping_bag),
      card('المصروفات', store.totalExpenses, Icons.payments),
      card('صافي الربح', store.profit, Icons.account_balance),
      const SizedBox(height: 10),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('الوصول السريع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: const [
          Chip(avatar: Icon(Icons.receipt_long, size: 18), label: Text('مبيعات')),
          Chip(avatar: Icon(Icons.shopping_cart, size: 18), label: Text('مشتريات')),
          Chip(avatar: Icon(Icons.inventory_2, size: 18), label: Text('مخزون')),
          Chip(avatar: Icon(Icons.people, size: 18), label: Text('عملاء')),
        ]),
      ]))),
    ],
  );
}

class SimpleListPage extends StatelessWidget {
  final String title, empty;
  final IconData icon;
  final List<Map<String,dynamic>> items;
  final VoidCallback onAdd;
  const SimpleListPage({super.key, required this.title, required this.icon, required this.items, required this.empty, required this.onAdd});

  @override
  Widget build(BuildContext context) => Scaffold(
    floatingActionButton: FloatingActionButton.extended(onPressed: onAdd, icon: const Icon(Icons.add), label: const Text('إضافة')),
    body: items.isEmpty ? Center(child: Text(empty)) : ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: items.length,
      itemBuilder: (_, i) => Card(child: ListTile(leading: Icon(icon), title: Text('عملية ${i+1}'), trailing: Text('₪ ${(items[i]['amount'] as num).toDouble().toStringAsFixed(2)}'))),
    ),
  );
}

class ProductsPage extends StatelessWidget {
  final AppStore store;
  const ProductsPage({super.key, required this.store});
  @override
  Widget build(BuildContext context) => Scaffold(
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () async {
        final n=TextEditingController(), b=TextEditingController(), s=TextEditingController(), q=TextEditingController();
        await showDialog(context: context, builder: (_) => AlertDialog(
          title: const Text('إضافة صنف'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller:n, decoration:const InputDecoration(labelText:'اسم الصنف')),
            TextField(controller:b, keyboardType:TextInputType.number, decoration:const InputDecoration(labelText:'سعر الشراء ₪')),
            TextField(controller:s, keyboardType:TextInputType.number, decoration:const InputDecoration(labelText:'سعر البيع ₪')),
            TextField(controller:q, keyboardType:TextInputType.number, decoration:const InputDecoration(labelText:'الكمية')),
          ]),
          actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:(){store.addProduct(n.text,double.tryParse(b.text)??0,double.tryParse(s.text)??0,double.tryParse(q.text)??0);Navigator.pop(context);},child:const Text('حفظ'))],
        ));
      },
      icon: const Icon(Icons.add), label: const Text('إضافة صنف'),
    ),
    body: store.products.isEmpty ? const Center(child: Text('لا توجد أصناف')) : ListView.builder(
      padding: const EdgeInsets.all(12), itemCount: store.products.length,
      itemBuilder: (_,i){final p=store.products[i];return Card(child: ListTile(leading:const Icon(Icons.inventory_2),title:Text(p['name']),subtitle:Text('الكمية: ${p['qty']}'),trailing:Text('₪ ${(p['sell'] as num).toDouble().toStringAsFixed(2)}')));},
    ),
  );
}

class PeoplePage extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Map<String,dynamic>> items;
  final List<String> fields;
  final VoidCallback onAdd;
  const PeoplePage({super.key, required this.title, required this.icon, required this.items, required this.fields, required this.onAdd});
  @override
  Widget build(BuildContext context)=>Scaffold(
    floatingActionButton:FloatingActionButton.extended(onPressed:onAdd,icon:const Icon(Icons.add),label:const Text('إضافة')),
    body:items.isEmpty?Center(child:Text('لا يوجد ${title.replaceAll('ال','')}')):ListView.builder(
      padding:const EdgeInsets.all(12),itemCount:items.length,
      itemBuilder:(_,i)=>Card(child:ListTile(leading:Icon(icon),title:Text(items[i]['name']??''),subtitle:Text(items[i]['phone']??''),trailing:Text('₪ ${(items[i]['balance']??0).toStringAsFixed(2)}'))),
    ),
  );
}

class ExpensesPage extends StatelessWidget {
  final AppStore store;
  const ExpensesPage({super.key, required this.store});
  @override
  Widget build(BuildContext context)=>Scaffold(
    floatingActionButton:FloatingActionButton.extended(
      onPressed:()async{final t=TextEditingController(),a=TextEditingController();await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('إضافة مصروف'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:t,decoration:const InputDecoration(labelText:'نوع المصروف')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'المبلغ ₪'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:(){store.addExpense(t.text,double.tryParse(a.text)??0);Navigator.pop(context);},child:const Text('حفظ'))]));},
      icon:const Icon(Icons.add),label:const Text('إضافة مصروف')),
    body:store.expenses.isEmpty?const Center(child:Text('لا توجد مصروفات')):ListView.builder(padding:const EdgeInsets.all(12),itemCount:store.expenses.length,itemBuilder:(_,i)=>Card(child:ListTile(leading:const Icon(Icons.payments),title:Text(store.expenses[i]['type']),trailing:Text('₪ ${(store.expenses[i]['amount'] as num).toDouble().toStringAsFixed(2)}')))),
  );
}

class EmployeesPage extends StatelessWidget {
  final AppStore store;
  const EmployeesPage({super.key, required this.store});
  @override
  Widget build(BuildContext context)=>Scaffold(
    floatingActionButton:FloatingActionButton.extended(onPressed:()async{final n=TextEditingController(),j=TextEditingController(),s=TextEditingController();await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('إضافة عامل'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'الاسم')),TextField(controller:j,decoration:const InputDecoration(labelText:'الوظيفة')),TextField(controller:s,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الراتب ₪'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:(){store.addEmployee(n.text,j.text,double.tryParse(s.text)??0);Navigator.pop(context);},child:const Text('حفظ'))]));},icon:const Icon(Icons.add),label:const Text('إضافة عامل')),
    body:store.employees.isEmpty?const Center(child:Text('لا يوجد عاملون')):ListView.builder(padding:const EdgeInsets.all(12),itemCount:store.employees.length,itemBuilder:(_,i)=>Card(child:ListTile(leading:const Icon(Icons.badge),title:Text(store.employees[i]['name']),subtitle:Text(store.employees[i]['job']),trailing:Text('₪ ${(store.employees[i]['salary'] as num).toDouble().toStringAsFixed(2)}')))),
  );
}

class ReportsPage extends StatelessWidget {
  final AppStore store;
  const ReportsPage({super.key, required this.store});
  @override
  Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('التقارير',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    _r('المبيعات',store.totalSales),
    _r('المشتريات',store.totalPurchases),
    _r('المصروفات',store.totalExpenses),
    _r('صافي الربح',store.profit),
  ]);
  Widget _r(String t,double v)=>Card(child:ListTile(title:Text(t),trailing:Text('₪ ${v.toStringAsFixed(2)}',style:const TextStyle(fontWeight:FontWeight.bold))));
}
